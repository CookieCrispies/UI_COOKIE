(this["webpackJsonpcubdefi-frontend"]=this["webpackJsonpcubdefi-frontend"]||[]).push([[12],{967:function(n,e){}}]);
//# sourceMappingURL=12.d3d42eed.chunk.js.map