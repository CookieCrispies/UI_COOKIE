(this["webpackJsonpcubdefi-frontend"]=this["webpackJsonpcubdefi-frontend"]||[]).push([[12],{968:function(n,e){}}]);
//# sourceMappingURL=12.a023dd9e.chunk.js.map