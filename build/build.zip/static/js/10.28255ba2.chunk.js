(this["webpackJsonpcubdefi-frontend"]=this["webpackJsonpcubdefi-frontend"]||[]).push([[10],{905:function(n,e){}}]);
//# sourceMappingURL=10.28255ba2.chunk.js.map