(this["webpackJsonpcubdefi-frontend"]=this["webpackJsonpcubdefi-frontend"]||[]).push([[10],{912:function(n,e){}}]);
//# sourceMappingURL=10.d00815f9.chunk.js.map