(this["webpackJsonpcubdefi-frontend"]=this["webpackJsonpcubdefi-frontend"]||[]).push([[8],{889:function(n,e){}}]);
//# sourceMappingURL=8.3c4248a7.chunk.js.map